# Task Tracker Web Version

This is a Streamlit web version of the original Tkinter Task Tracker.

## Run locally
1. Install Python.
2. Open a terminal in this folder.
3. Run: `pip install -r requirements.txt`
4. Run: `streamlit run app.py`

## Deploy
Upload `app.py` and `requirements.txt` to a GitHub repository, then create an app at https://share.streamlit.io/ and choose `app.py` as the main file.

## Important
This starter version stores tasks in the active Streamlit browser session only. For durable storage and syncing between devices/users, connect a database before relying on it for important tasks.
