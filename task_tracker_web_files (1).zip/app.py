import streamlit as st
from datetime import datetime, date, time

st.set_page_config(page_title="My Task Tracker", page_icon="✓", layout="wide")

# A web version inspired by the original Tkinter app.
# Tasks are stored in this browser session only. Add a database for cross-device persistence.

PRIMARY = "#6C63FF"

st.markdown("""
<style>
.stApp { background: #F4F6FB; }
.block-container { padding-top: 2rem; max-width: 1400px; }
h1, h2, h3, p, label { color: #252A3D; }
div[data-testid="stMetric"] {
  background: white; padding: 16px; border-radius: 14px;
  border-left: 5px solid #6C63FF;
}
.stButton button[kind="primary"] { background: #6C63FF; border-color: #6C63FF; }
</style>
""", unsafe_allow_html=True)

if "username" not in st.session_state:
    st.session_state.username = ""
if "tasks" not in st.session_state:
    st.session_state.tasks = []

def task_due(task):
    if not task.get("due_date"):
        return None
    try:
        return datetime.strptime(task["due_date"], "%d-%m-%Y %I:%M %p")
    except (ValueError, TypeError):
        return None

def is_overdue(task):
    due = task_due(task)
    return task["status"] != "Completed" and due is not None and due < datetime.now()

if not st.session_state.username:
    st.markdown("# ✓ My Task Tracker")
    st.caption("Your personal productivity space")
    with st.form("welcome_form"):
        name = st.text_input("What should we call you?", placeholder="Enter your name")
        submitted = st.form_submit_button("Continue →", type="primary")
        if submitted:
            if name.strip():
                st.session_state.username = name.strip()
                st.rerun()
            else:
                st.warning("Please enter your name.")
    st.stop()

st.title("✓ My Task Tracker")
st.write(f"Welcome, **{st.session_state.username}** 👋")
st.caption(datetime.now().strftime("%A, %d %B %Y"))

tasks = st.session_state.tasks
total = len(tasks)
completed = sum(t["status"] == "Completed" for t in tasks)
pending = total - completed
percent = int((completed / total) * 100) if total else 0

c1, c2, c3, c4 = st.columns(4)
c1.metric("TOTAL TASKS", total)
c2.metric("PENDING", pending)
c3.metric("COMPLETED", completed)
c4.metric("PROGRESS", f"{percent}%")
st.progress(percent / 100 if total else 0)

left, right = st.columns([1, 2.2], gap="large")

with left:
    st.subheader("Create Task")
    with st.form("add_task_form", clear_on_submit=True):
        title = st.text_input("Task", placeholder="What do you need to do?")
        category = st.selectbox("Category", ["Study", "Work", "Personal", "College", "Health", "Shopping", "General"])
        priority = st.selectbox("Priority", ["High", "Medium", "Low"], index=1)
        add_deadline = st.checkbox("Add deadline")
        due_day = st.date_input("Due date", value=date.today(), disabled=not add_deadline)
        due_time = st.time_input("Due time", value=time(18, 0), disabled=not add_deadline)
        notes = st.text_area("Notes", placeholder="Optional details...")
        add = st.form_submit_button("＋ Add Task", type="primary", use_container_width=True)
        if add:
            if not title.strip():
                st.warning("Please enter a task first.")
            else:
                due_string = datetime.combine(due_day, due_time).strftime("%d-%m-%Y %I:%M %p") if add_deadline else "No deadline"
                tasks.append({
                    "title": title.strip(),
                    "category": category,
                    "priority": priority,
                    "due_date": due_string,
                    "date": datetime.now().strftime("%d %b %Y, %I:%M %p"),
                    "status": "Pending",
                    "notes": notes.strip()
                })
                st.rerun()

with right:
    st.subheader("Your Tasks")
    search = st.text_input("Search tasks", placeholder="Search title, category, priority, status or notes")
    filter_choice = st.selectbox("Filter tasks", ["All", "Today", "Upcoming", "Overdue", "Pending", "Completed", "High Priority"])
    visible = list(enumerate(tasks))
    now = datetime.now()
    if search.strip():
        q = search.strip().lower()
        visible = [(i,t) for i,t in visible if q in t["title"].lower() or q in t["category"].lower() or q in t["priority"].lower() or q in t["status"].lower() or q in t["notes"].lower()]
    if filter_choice == "Pending":
        visible = [(i,t) for i,t in visible if t["status"] == "Pending"]
    elif filter_choice == "Completed":
        visible = [(i,t) for i,t in visible if t["status"] == "Completed"]
    elif filter_choice == "High Priority":
        visible = [(i,t) for i,t in visible if t["priority"] == "High"]
    elif filter_choice == "Overdue":
        visible = [(i,t) for i,t in visible if is_overdue(t)]
    elif filter_choice == "Today":
        visible = [(i,t) for i,t in visible if task_due(t) and task_due(t).date() == now.date()]
    elif filter_choice == "Upcoming":
        visible = [(i,t) for i,t in visible if task_due(t) and task_due(t) > now and t["status"] != "Completed"]
    visible.sort(key=lambda pair: task_due(pair[1]) or datetime.max)

    if not visible:
        st.info("No tasks to show. Add a task using the form.")
    for index, task in visible:
        due = task["due_date"]
        badge = "✅ Completed" if task["status"] == "Completed" else ("⚠️ Overdue" if is_overdue(task) else "○ Pending")
        with st.container(border=True):
            top1, top2 = st.columns([3, 1])
            top1.markdown(f"**{task['title']}**")
            top2.write(badge)
            st.caption(f"{task['category']} · {task['priority']} priority · Due: {due}")
            if task.get("notes"):
                st.write(task["notes"])
            a, b, c = st.columns(3)
            if task["status"] != "Completed":
                if a.button("✓ Complete", key=f"complete_{index}", use_container_width=True):
                    tasks[index]["status"] = "Completed"
                    st.rerun()
            else:
                if a.button("↩ Reopen", key=f"reopen_{index}", use_container_width=True):
                    tasks[index]["status"] = "Pending"
                    st.rerun()
            if b.button("✏ Edit", key=f"edit_toggle_{index}", use_container_width=True):
                st.session_state[f"editing_{index}"] = not st.session_state.get(f"editing_{index}", False)
                st.rerun()
            if c.button("🗑 Delete", key=f"delete_{index}", use_container_width=True):
                tasks.pop(index)
                st.rerun()
            if st.session_state.get(f"editing_{index}", False):
                with st.form(f"edit_form_{index}"):
                    new_title = st.text_input("Task title", value=task["title"])
                    new_category = st.selectbox("Category", ["Study", "Work", "Personal", "College", "Health", "Shopping", "General"], index=["Study", "Work", "Personal", "College", "Health", "Shopping", "General"].index(task["category"]) if task["category"] in ["Study", "Work", "Personal", "College", "Health", "Shopping", "General"] else 6)
                    new_priority = st.selectbox("Priority", ["High", "Medium", "Low"], index=["High", "Medium", "Low"].index(task["priority"]) if task["priority"] in ["High", "Medium", "Low"] else 1)
                    new_notes = st.text_area("Notes", value=task.get("notes", ""))
                    save_edit = st.form_submit_button("Save changes", type="primary")
                    if save_edit:
                        if new_title.strip():
                            tasks[index].update(title=new_title.strip(), category=new_category, priority=new_priority, notes=new_notes.strip())
                            st.session_state[f"editing_{index}"] = False
                            st.rerun()
                        else:
                            st.warning("Task title cannot be empty.")

st.divider()
if tasks:
    if st.button("❌ Clear all tasks"):
        st.session_state.confirm_clear = True
    if st.session_state.get("confirm_clear", False):
        st.warning("Are you sure you want to delete all tasks?")
        yes, no = st.columns(2)
        if yes.button("Yes, clear all", type="primary"):
            st.session_state.tasks = []
            st.session_state.confirm_clear = False
            st.rerun()
        if no.button("Cancel"):
            st.session_state.confirm_clear = False
            st.rerun()

st.caption("Note: This hosted demo keeps tasks in the current browser session. Tasks are not yet saved to a permanent cloud database or synced across devices.")
